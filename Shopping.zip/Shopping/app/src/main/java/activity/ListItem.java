package activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.shopping.R;

public class ListItem  {
    private String Name;
    private String Description;
    private String Image_url;
    public ListItem (String Name,String Description,String Image_url) {
        this.Name = Name;
    this.Description=Description;
    this.Image_url=Image_url;
    }

    public String getName() {
        return Name;
    }

    public String getDescription() {
        return Description;
    }

    public String getImage_url() {
        return Image_url;
    }
}