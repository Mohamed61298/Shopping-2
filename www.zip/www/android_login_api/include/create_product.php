<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['id']) && isset($_POST['Shop_id']) && isset($_POST['Product_id']&& isset($_POST['ShopName'])&& isset($_POST['ProductName']&& isset($_POST['Price']&& isset($_POST['SpecialOffers']) {
 
    $id= $_POST['id'];
    $Shop_id = $_POST['Shop_id'];
    $Product_id = $_POST['Product_id'];
    $ShopName = $_POST['ShopName'];
    $ProductName = $_POST['ProductName'];
    $Price = $_POST['Price'];
    $SpecialOffers = $_POST['SpecialOffers'];
    // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();
 
    // mysql inserting a new row
    $result = mysql_query("INSERT INTO products(id, Shop_id, Product_id,ShopName,ProductName,Price,SpecialOffers) VALUES('$id', '$Shop_id', '$Product_id','$ShopName''$ProductName''$Price''$SpecialOffers')");
 
    // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "Product successfully created.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        echo json_encode($response);
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>